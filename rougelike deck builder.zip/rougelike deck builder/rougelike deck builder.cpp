// rougelike deck builder.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include <iostream>

class Player {
private:
    float x, y, z;   
    float speed;     

public:
    Player(float startX, float startY, float startZ, float moveSpeed)
        : x(startX), y(startY), z(startZ), speed(moveSpeed) {
    }

    void Move(float dx, float dz) {
        x += dx * speed;
        z += dz * speed;
    }

    void Jump(float force) {
        y += force; 
    }

    void PrintPosition() {
        std::cout << "Player Position: (" << x << ", " << y << ", " << z << ")\n";
    }
};

int main() {
    Player player(0.0f, 0.0f, 0.0f, 0.1f);

    player.Move(1.0f, 0.0f);  
    player.Move(0.0f, 1.0f);  
    player.Jump(1.0f);        
    player.PrintPosition();

    return 0;
}
